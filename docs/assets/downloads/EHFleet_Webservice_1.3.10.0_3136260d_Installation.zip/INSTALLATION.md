﻿# EHFleet Webservice Installation

Version: 1.3.10.0
Commit: 3136260d264d2de5cc35e536e1221b133839c171
Paket erstellt: 2026-11-02T11:04:13Z

## Inhalt

- `ehfleet_webservice.zip` - Web-Deploy-Paket für IIS.
- `Install-EHFleetWebservice.ps1` - Installationsskript für IIS, App-Pool, Web Deploy und Datenbankverbindung.
- `Update-EHFleetWebservice.ps1` - Update mit Sicherung und Wiederherstellung.
- `EHFleetDeployment.psm1` - gemeinsames Modul; neben den Skripten belassen.
- `UPDATE.md` und `INSTALLATION-DETAILS.md` - ausführliche Anleitungen.
- `README.md` - technische Projektübersicht.
- `CHANGELOG.md` - Änderungsprotokoll.

## Schnellstart

PowerShell als Administrator starten, Paket entpacken und aus dem entpackten Ordner ausführen:

```powershell
$sqlLogin = Get-Credential -Message 'SQL-Anmeldung für FLEET'
.\Install-EHFleetWebservice.ps1 `
  -SiteName 'FLEET Webservice' `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -SqlCredential $sqlLogin
```

Für Windows-Authentifizierung:

```powershell
.\Install-EHFleetWebservice.ps1 `
  -SiteName 'FLEET Webservice' `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -UseWindowsAuth
```

Weitere Hinweise stehen in der öffentlichen Installationsanleitung.

Bestehende Installation aktualisieren:

```powershell
.\Update-EHFleetWebservice.ps1 `
  -SiteName 'FLEET Webservice' `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SmokeTestUrl 'http://localhost:8080/ehfleet_webservice/WorkshopItems.asmx?WSDL'
```

Windows PowerShell 5.1 als Administrator verwenden. Web Deploy 3.6 und .NET Framework 4.8 müssen vorab installiert sein.
Die Neuinstallation verlangt eine freie Anwendung und ein leeres Zielverzeichnis; das Update erhält die vorhandene Konfiguration.
